After extracting all of the files to a directory somewhere, run the RUNTOPATCH.bat file, it will request admin privileges and then add Game Explorer to your system.
Note that you may or may not have to redo the patch after every update, and you DO have to REDO THE PATCH after every system repair (possibly excluding system restore and definitely including sfc), depending on if it has new icons or not.
If there has been a restore point created in the last 24 hours, the script cannot make one, so you will have to do it yourself.

The patch almost instantly applies itself to the system, then afterwards the system will restart after 10 seconds.
IMPORTANT: Close all open windows and save all unsaved documents before executing this program.

After installing, clearing the icon cache, and restarting you can open games explorer by either entering this into the run dialog:
shell:::{ED228FDF-9EA8-4870-83b1-96b02CFE0D52}

Or by naming a folder this:
Games.{ED228FDF-9EA8-4870-83b1-96b02CFE0D52}

ALSO MAKE SURE THAT TAMPER PROTECTION IS OFF TO AVOID CAUSING IT TO BE REVERTED