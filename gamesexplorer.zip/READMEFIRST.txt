After running the patch, here is what you should do.
1: Press start, type "cleanup", then press on disk cleanup.
2: Deselect everything that are not thumbnails
3: Hold shift while pressing the restart button in the start menu (Start > Power > Shift + Restart), this puts the computer in recovery mode
4: Select troubleshoot
5: Select advanced options
6: Select command prompt
7: When prompted, select your username and enter your password.
8: Find your system drive (it may or may not be C:\ in recovery mode) using the command [letter]:, starting with C: and working down the alphabet.
8.1: To check if it is your system drive, run dir and check if both windows and workingdir are present (workingdir is where the patched file is)
9: If so, execute copy /y workingdir\imageres.dll.mun windows\systemresources\imageres.dll.mun, otherwise continue with step 8.
10: Execute wpeutil restart
11: You are done!

The reason why this part is not automated is because Windows cannot modify critical icon files without recovery mode to include the icon while Windows is running normally.